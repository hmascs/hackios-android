#!/system/bin/sh
set -eu
base=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)
unset VK_INSTANCE_LAYERS VK_LOADER_LAYERS_ENABLE VK_LOADER_LAYERS_DISABLE LIBGL_ALWAYS_SOFTWARE
export LD_LIBRARY_PATH="$base/lib"
export VK_DRIVER_FILES="$base/config/turnip.json"
export VK_LAYER_PATH="$base/config/empty"
export VK_IMPLICIT_LAYER_PATH="$base/config/empty"
export __EGL_VENDOR_LIBRARY_FILENAMES="$base/config/zink-egl.json"
export LIBGL_DRIVERS_PATH="$base/lib/dri"
export EGL_PLATFORM=surfaceless MESA_LOADER_DRIVER_OVERRIDE=zink GALLIUM_DRIVER=zink LIBGL_KOPPER_DISABLE=true
exec "$base/bin/hackios-zink-session" "$@"
