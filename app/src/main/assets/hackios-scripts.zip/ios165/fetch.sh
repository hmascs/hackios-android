#!/bin/bash
# Get the files of iOS 16.5 (20F66, iPhone X) that the system image is made of, straight from
# Apple's servers, and lay them out the way ../userland/build.sh expects them:
#
#   rootfs/                  the chosen part of the root filesystem (see select-system.py)
#   system.files/.manifest   what was chosen, with owners, modes and symbolic links
#   var.skel                 the skeleton of /private/var (see mkvarskel.py)
#   cryptex/                 the OS cryptex without the dyld shared cache
#   cryptex-app.dmg          the App cryptex as Apple ships it (10 MB, an APFS container: Safari's
#                            daemons, its settings and the bundles around it, which the root volume's
#                            launchd jobs and links reach through /System/Cryptexes/App)
#   cryptex-app/             ... and its files
#   20F66__iPhone10,3_6/     the dyld shared cache (arm64)
#
# Nothing of this is in the repository: the two disk images are fetched out of the IPSW on
# Apple's CDN (fetch-from-ipsw.py reads single members of the archive, 4.7 GB + 2.7 GB instead of
# all 6.2 GB) and unpacked with 7z. Needs: python3, 7z (7-Zip 23 or newer: it reads APFS), cc.
# About 8 GB of disk while it runs, 5.3 GB afterwards.
#
#   KEEP=1   keep the downloaded disk images (rootfs.dmg is needed again only after changing
#            select-system.py; with it in place a second run downloads nothing)
set -e
# The unpack steps below are pipelines (7z | tr | tee); without pipefail a failed 7z would be
# masked by tee's exit status and the script would happily continue with a half-unpacked tree.
set -o pipefail
cd "$(dirname "$0")"
# The umask of the process that runs this, which on Android is 077: every file 7z extracts here
# would come out 0600 (0700 for a directory) wherever it writes the mode through open(2) instead
# of an explicit chmod. The cryptex trees have no manifest to carry the modes back -- that is the
# rootfs' privilege -- so what is extracted here is the mode the image will have. A cryptex
# libobjc-trampolines.dylib that arrives 0600 reaches /usr/lib in the image as 0600, and the first
# process running as mobile to dlopen it gets "open() failed with errno=13" (EACCES): that is how
# SpringBoard died on 24 October 2026, with the black screen, on a build whose graft was correct.
# 022 leaves 7z's own mode alone, the way it comes out on a Mac.
umask 022
ROOTFS_DMG=096-04088-077.dmg                    # the root filesystem, APFS
CRYPTEX_DMG=096-04666-078.dmg                   # the OS cryptex: dyld shared cache and a few libraries
APP_CRYPTEX_DMG=096-03536-083.dmg               # the App cryptex (BuildManifest: Cryptex1,AppOS)
CACHE=20F66__iPhone10,3_6
UNZBM=../xnu-deps/host/bin/unzbm
SEVENZIP=${SEVENZIP:-7zz}   # standalone 7-Zip: no external codec library

for tool in python3 7zz; do
	command -v $tool >/dev/null || { echo "fetch.sh: $tool is not installed"; exit 1; }
done
# 7z leaves files compressed with LZBITMAP as an empty file and two attribute files; unzbm finishes them
if [ ! -x $UNZBM ]; then
	mkdir -p "$(dirname $UNZBM)"
	cc -O2 -w -o $UNZBM ../xnu-deps/build/lzbitmap/unzbm.c ../xnu-deps/build/lzbitmap/libzbitmap.c
fi
# 7z refreshes its progress on ONE line with \r, and the caller used to redirect stdout to a log
# file: the app, which reads this script's stdout, therefore saw nothing for the 40 minutes a
# 4.7 GB tree takes and showed the previous stage's 100 % the whole time. -bsp1 sends the progress
# to stdout, tr turns the \r refresh into lines the app can parse ("  12% 34 - path"), and tee
# keeps the log file as before. stderr (7z's "Unsupported Method" for every LZBITMAP file, which
# is expected here) goes straight to the log: hundreds of those lines would flood the UI log.
unpack() { # unpack LOGFILE 7z-args...
	local log=$1; shift
	: > "$log"          # last run's progress lines would otherwise pile up in the log
	# -bb1, not just -bsp1: with stdout on a pipe 7-Zip sends the percentage ONCE (measured: a
	# 74-second pack printed a single "0%"), so the shared progress line never arrives here. -bb1
	# prints one line per extracted file and each carries the running percentage ("  54% 912 - p"),
	# which is what the app parses.
	$SEVENZIP "$@" -bsp1 -bb1 2>> "$log" | tr '\r' '\n' | tee -a "$log"
	# -bb1 stops at 99 % for the last member (it reports "about to write", not "written"), and the
	# app would sit on 99 % until the next phase. The exit code above is what proves the unpack
	# finished, so this is honest.
	echo "100%"
}
unzbm_all() { # unzbm_all DIR: expand every LZBITMAP file below DIR
	find "$1" -type f -name '*:com.apple.decmpfs' | sed 's/:com\.apple\.decmpfs$//' | tr '\n' '\0' | xargs -0 -r -n 200 $UNZBM
	local left
	left=$(find "$1" -name '*:com.apple.*' | wc -l)
	[ "$left" = 0 ] || { echo "fetch.sh: $left files in $1 are still compressed"; exit 1; }
}

# --- the root filesystem --------------------------------------------------------------------------
if [ ! -f .done-rootfs ] || [ select-system.py -nt .done-rootfs ]; then
	if [ ! -f rootfs.dmg ]; then
		echo "fetch.sh: downloading the root filesystem image (4.7 GB)"
		python3 fetch-from-ipsw.py $ROOTFS_DMG rootfs.dmg.part
		mv rootfs.dmg.part rootfs.dmg
	fi
	echo "fetch.sh: listing the image"
	$SEVENZIP l -slt rootfs.dmg > rootfs.slt
	python3 select-system.py rootfs.slt system.files system.manifest
	python3 mkvarskel.py rootfs.slt > var.skel
	echo "fetch.sh: extracting $(wc -l < system.files) files"
	rm -rf rootfs
	unpack extract-system.log x -y -orootfs rootfs.dmg @system.files
	# the two fonts too big for the image as they are, made smaller in place (see select-system.py)
	python3 ../tools/font_trim.py emoji rootfs/System/Library/Fonts/CoreAddition/AppleColorEmoji-160px.ttc \
		rootfs/System/Library/Fonts/CoreAddition/AppleColorEmoji-160px.ttc 40,64,96
	python3 ../tools/font_trim.py faces rootfs/System/Library/Fonts/LanguageSupport/PingFang.ttc \
		rootfs/System/Library/Fonts/LanguageSupport/PingFang.ttc '^\.?PingFang(SC|TC|HK)-(Regular|Semibold)$'
	touch .done-rootfs
	[ -n "$KEEP" ] || rm -f rootfs.dmg
fi

# --- the OS cryptex -------------------------------------------------------------------------------
if [ ! -f .done-cryptex ]; then
	if [ ! -f cryptex-os.dmg ]; then
		echo "fetch.sh: downloading the OS cryptex image (2.7 GB)"
		python3 fetch-from-ipsw.py $CRYPTEX_DMG cryptex-os.dmg.part
		mv cryptex-os.dmg.part cryptex-os.dmg
	fi
	echo "fetch.sh: extracting the cryptex"
	rm -rf cryptex cryptex.cache $CACHE
	# 7z reports every LZBITMAP file as an error ("Unsupported Method"): expected, unzbm_all checks the result
	unpack extract-cryptex.log x -y -ocryptex cryptex-os.dmg '-xr!com.apple.dyld' '-x!System/DriverKit' || true
	unzbm_all cryptex
	# the dyld shared cache; its .symbols file (0.6 GB) is never mapped and is left out
	unpack extract-dyld.log x -y -ocryptex.cache cryptex-os.dmg System/Library/Caches/com.apple.dyld '-xr!*.symbols*' || true
	unzbm_all cryptex.cache
	mv cryptex.cache/System/Library/Caches/com.apple.dyld $CACHE
	rm -rf cryptex.cache
	[ "$(ls $CACHE | wc -l)" = 43 ] || { echo "fetch.sh: the dyld shared cache is incomplete"; exit 1; }
	touch .done-cryptex
	[ -n "$KEEP" ] || rm -f cryptex-os.dmg
fi

# --- the App cryptex ------------------------------------------------------------------------------
# kept as it is (the boot off the flash puts it in memory unchanged, ../userland/build.sh FLASHBOOT=1)
# and unpacked (the system image has its files at /System/Cryptexes/App)
if [ ! -f .done-cryptex-app ]; then
	if [ ! -f cryptex-app.dmg ]; then
		echo "fetch.sh: downloading the App cryptex image (10 MB)"
		python3 fetch-from-ipsw.py $APP_CRYPTEX_DMG cryptex-app.dmg.part
		mv cryptex-app.dmg.part cryptex-app.dmg
	fi
	echo "fetch.sh: extracting the App cryptex"
	rm -rf cryptex-app
	unpack extract-cryptex-app.log x -y -ocryptex-app cryptex-app.dmg || true
	unzbm_all cryptex-app
	[ -f cryptex-app/usr/libexec/webbookmarksd ] || { echo "fetch.sh: the App cryptex is incomplete"; exit 1; }
	touch .done-cryptex-app
fi
echo "fetch.sh: done: $(du -sh rootfs | cut -f1) rootfs, $(du -sh cryptex | cut -f1) cryptex, $(du -sh cryptex-app | cut -f1) App cryptex, $(du -sh $CACHE | cut -f1) dyld shared cache"
